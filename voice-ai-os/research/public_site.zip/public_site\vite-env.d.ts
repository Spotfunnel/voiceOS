
/// <reference types="vite/client" />
