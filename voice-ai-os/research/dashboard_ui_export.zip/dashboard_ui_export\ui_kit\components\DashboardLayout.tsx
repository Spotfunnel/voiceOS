
import React from "react";
import { LayoutDashboard, PlusCircle, Settings, Activity, BrainCircuit } from "lucide-react";
import { cn } from "../lib/utils";

interface LayoutProps {
    children: React.ReactNode;
    activeResult?: "operations" | "new_agent" | "configure" | "quality" | "intelligence";
}

const NAV_ITEMS = [
    { id: "operations", label: "Operations", icon: Activity, href: "/operations" },
    { id: "new_agent", label: "New Agent", icon: PlusCircle, href: "/new-agent" },
    { id: "intelligence", label: "Intelligence", icon: BrainCircuit, href: "/intelligence" },
    { id: "configure", label: "Configure", icon: Settings, href: "/configure" },
    { id: "quality", label: "Quality", icon: LayoutDashboard, href: "/quality" },
];

export function DashboardLayout({ children, activeResult = "operations" }: LayoutProps) {
    return (
        <div className="min-h-screen bg-slate-50/50 flex flex-col md:flex-row font-sans text-slate-900">
            {/* Sidebar Navigation */}
            <aside className="w-full md:w-64 bg-white border-r border-slate-200 flex-shrink-0 z-10">
                <div className="p-6 border-b border-slate-100 flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <div className="w-4 h-4 rounded-sm bg-primary" />
                    </div>
                    <span className="font-bold text-lg tracking-tight text-slate-900">SpotFunnel</span>
                </div>

                <nav className="p-4 space-y-1">
                    <div className="px-2 py-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
                        Platform
                    </div>
                    {NAV_ITEMS.map((item) => {
                        const isActive = activeResult === item.id;
                        return (
                            <a
                                key={item.id}
                                href="#"
                                className={cn(
                                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                                    isActive
                                        ? "bg-slate-100 text-primary"
                                        : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                                )}
                            >
                                <item.icon className={cn("w-4 h-4", isActive ? "text-primary" : "text-slate-400")} />
                                {item.label}
                            </a>
                        );
                    })}
                </nav>

                <div className="absolute bottom-0 left-0 w-full p-4 border-t border-slate-100">
                    <div className="flex items-center gap-3 px-2">
                        <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200" />
                        <div className="flex-1 overflow-hidden">
                            <p className="text-sm font-medium truncate">Kai Operator</p>
                            <p className="text-xs text-slate-500 truncate">kai@spotfunnel.com</p>
                        </div>
                    </div>
                </div>
            </aside>

            {/* Main Content Area */}
            <main className="flex-1 overflow-y-auto min-h-screen">
                <header className="h-16 border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-20 px-6 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-slate-500">
                        <span>Dashboard</span>
                        <span className="text-slate-300">/</span>
                        <span className="font-medium text-slate-900 capitalize">{activeResult.replace('_', ' ')}</span>
                    </div>

                    <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-full border border-emerald-100 shadow-sm">
                            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            <span className="text-xs font-semibold">System Operational</span>
                        </div>
                    </div>
                </header>

                <div className="p-6 md:p-8 max-w-7xl mx-auto animate-enter">
                    {children}
                </div>
            </main>
        </div>
    );
}
