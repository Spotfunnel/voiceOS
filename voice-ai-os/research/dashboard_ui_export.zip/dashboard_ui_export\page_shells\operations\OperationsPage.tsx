
import React from 'react';
import { DashboardLayout } from '../../ui_kit/components/DashboardLayout';
import { StatsCard } from '../../ui_kit/components/ui/StatsCard';
import { Card, CardHeader, CardTitle, CardContent } from '../../ui_kit/components/ui/Card';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '../../ui_kit/components/ui/Table';
import { Badge } from '../../ui_kit/components/ui/Badge';
import { Phone, Users, AlertTriangle, CheckCircle2, Clock } from 'lucide-react';
import { mockId } from '../../ui_kit/lib/utils';

// Mock Data
const AGENTS = [
    { id: mockId(), name: "Inbound Reception A", status: "Active", minutes: "450 / 1000", lastError: "None", health: "healthy" },
    { id: mockId(), name: "Sales Outreach B", status: "Active", minutes: "890 / 1000", lastError: "20m ago", health: "warning" },
    { id: mockId(), name: "Support Tier 1", status: "Paused", minutes: "120 / 500", lastError: "2h ago", health: "healthy" },
    { id: mockId(), name: "After Hours", status: "Active", minutes: "12 / 200", lastError: "None", health: "healthy" },
    { id: mockId(), name: "Booking Concierge", status: "Error", minutes: "0 / 1000", lastError: "Now", health: "critical" },
];

export function OperationsPage() {
    return (
        <DashboardLayout activeResult="operations">
            <div className="space-y-8">
                {/* 1. Global Health Strip */}
                <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-sm">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center">
                            <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                        </div>
                        <div>
                            <h2 className="text-lg font-bold text-slate-900">System Healthy</h2>
                            <p className="text-sm text-slate-500">All primary voice circuits operational.</p>
                        </div>
                    </div>
                    <div className="flex gap-8 px-8 border-l border-slate-100">
                        <div>
                            <p className="text-xs font-bold text-slate-400 uppercase">Uptime (24h)</p>
                            <p className="text-lg font-mono font-medium text-slate-900">99.98%</p>
                        </div>
                        <div>
                            <p className="text-xs font-bold text-slate-400 uppercase">Avg Latency</p>
                            <p className="text-lg font-mono font-medium text-slate-900">420ms</p>
                        </div>
                    </div>
                </div>

                {/* 2. Key Metrics - "Float to Top" */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <StatsCard
                        title="Active Calls Now"
                        value="12"
                        trend="neutral"
                        trendValue="Normal Load"
                        icon={Phone}
                    />
                    <StatsCard
                        title="Calls (24h)"
                        value="1,248"
                        trend="up"
                        trendValue="+12% vs avg"
                        icon={Users}
                    />
                    <StatsCard
                        title="Errors (24h)"
                        value="3"
                        trend="down"
                        trendValue="-2 from yest"
                        icon={AlertTriangle}
                    />
                    <StatsCard
                        title="Minutes Used"
                        value="14,204"
                        trend="up"
                        trendValue="82% of Cap"
                        icon={Clock}
                        className="border-amber-200 bg-amber-50/30" // Subtle warning indication
                    />
                </div>

                {/* 3. Agent Status Table */}
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle>Agent Status</CardTitle>
                        <Badge variant="outline" className="bg-slate-50">5 Agents Configured</Badge>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Agent Name</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Minutes Usage</TableHead>
                                    <TableHead>Last Incident</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {AGENTS.map((agent) => (
                                    <TableRow key={agent.id}>
                                        <TableCell className="font-medium text-slate-900">{agent.name}</TableCell>
                                        <TableCell>
                                            <Badge variant={
                                                agent.health === 'healthy' ? 'success' :
                                                    agent.health === 'warning' ? 'warning' : 'destructive'
                                            }>
                                                {agent.status}
                                            </Badge>
                                        </TableCell>
                                        <TableCell className="font-mono text-xs">{agent.minutes}</TableCell>
                                        <TableCell className="text-slate-500">{agent.lastError}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>

                {/* 4. Alerts Preview */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
                        <div>
                            <h4 className="text-sm font-bold text-amber-800">Capacity Warning</h4>
                            <p className="text-sm text-amber-700 mt-1">
                                Sales Outreach B is approaching its hard minute cap (89%). Consider increasing allocation before weekend surge.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </DashboardLayout>
    );
}
