# Security Policy

## Reporting a Vulnerability

Please email `disclosures@daily.co`.
